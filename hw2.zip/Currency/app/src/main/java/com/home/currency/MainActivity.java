package com.home.currency;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    private EditText ntd;
    private TextView jp;
    private TextView us;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findView();
    }
    private void findView() {
        ntd = findViewById(R.id.ntd);
        jp = findViewById(R.id.jp);
        us = findViewById(R.id.us);
        //取值
    }
    public void trans (View view){
        String n = ntd.getText().toString(); //轉string
        if ( n != null && !n.equals("")){
            float nt_dollars = Float.parseFloat(n); //轉float
            float usd = nt_dollars/30.9f;
            float jpd = nt_dollars/0.27f;
            jp.setText("$ "+jpd);
            us.setText("$ "+usd);
            new AlertDialog.Builder(this)
                    .setTitle("Exchange Rate")
                    .setMessage("JP is "+ jpd+'\n'+"USD is "+ usd)
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ntd.setText(" ");
                            jp.setText(" ");
                            us.setText(" ");
                        }
                    })
                    .show();
        }else{
            new AlertDialog.Builder(this)
                    .setTitle("Problem")
                    .setMessage("Please enter your NTD amount")
                    .setPositiveButton("ok", null)
                    .show();
        }
    }
}


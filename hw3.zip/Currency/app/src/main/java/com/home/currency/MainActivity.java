package com.home.currency;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    private EditText ntd;
    private TextView jp;
    private TextView us;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findView();
    }
    private void findView() {
        ntd = findViewById(R.id.ntd);
        jp = findViewById(R.id.jp);
        us = findViewById(R.id.us);
        //取值
    }
    public void trans (View view){
        String n = ntd.getText().toString(); //轉string
        if ( n != null && !n.equals("")){
            float nt_dollars = Float.parseFloat(n); //轉float
            float usd = nt_dollars/30.9f;
            float jpd = nt_dollars/0.27f;
            jp.setText("$ "+jpd);
            us.setText("$ "+usd);
            new AlertDialog.Builder(this)
                    .setTitle(getString(R.string.exchange_rate))
                    .setMessage(getString(R.string.jpd_is)+ jpd+'\n'+getString(R.string.usd_is)+ usd)
                    .setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ntd.setText(" ");
                            jp.setText(" ");
                            us.setText(" ");
                        }
                    })
                    .show();
        }else{
            new AlertDialog.Builder(this)
                    .setTitle(getString(R.string.problem))
                    .setMessage(getString(R.string.enter))
                    .setPositiveButton(getString(R.string.ok), null)
                    .show();
        }
    }
}

